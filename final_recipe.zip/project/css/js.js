const getElement = (selector) => {
    const element = document.querySelector(selector)
    
    document.getElementById("ico").style.visibility = "hidden";
    if (element) return element
    throw Error(
      `Please double check your class names, there is no ${selector} class`
    )
  }
  
  const links = getElement('.nav-links')
  const navBtnDOM = getElement('.nav-btn')
  
  navBtnDOM.addEventListener('click', () => {
    document.getElementById("ico").style.visibility = "hidden";
    document.getElementById("ico").style.display='none';
      document.getElementById("lin").style.marginLeft = "0";
    links.classList.toggle('show-links')
    document.getElementById("lin").style.marginLeft = "0";
  
  
  })